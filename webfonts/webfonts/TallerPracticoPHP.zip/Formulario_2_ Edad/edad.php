<?php 

$nombre = $_POST['nombre'];
$edad = $_POST['edad'];

echo "Su nombre es ".$nombre." y su edad es ".$edad;


?>
